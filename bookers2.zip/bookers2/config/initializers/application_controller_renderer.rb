# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd5ad10a138c250bb2e1e97de1de36ecaf5e55a0fe8092e8af64a1f50727c859d9b8d0f32eef18bbcb49ad87e198d8bd0862d854e2ea54b0cf54c8b77b68be4eb'