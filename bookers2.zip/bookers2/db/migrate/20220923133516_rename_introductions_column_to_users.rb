class RenameIntroductionsColumnToUsers < ActiveRecord::Migration[5.2]
  def change
    rename_column :users, :introductions, :introduction
  end
end
